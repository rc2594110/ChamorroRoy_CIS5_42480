/* 
 * File:   main.cpp
 * Author: Roy Chamorro
 * Created on February 21, 2018, 5:05 PM
 * Purpose:  This is our first lab assignment 
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv)
    {
    double PumpPrice;
    double OilCo;
    double FedTax;
    double StaTax;
    double SalTax;
    double BasePrice;
    double TotTax;
    double PercentTax; //"Percentage price due to gas tax"
    double PumpTax; //Specific sale tax total on my PumpPrice
    double GasPer; //"Percentage price due to gas tax"
    double OilRange; // "Oil Company profit range"
   
            PumpPrice = 3.25;
            OilCo = .07;
            FedTax = .184;
            StaTax = .417;
            SalTax = .0225;
            PumpTax = PumpPrice * SalTax;
            TotTax = FedTax + StaTax + PumpTax;
            GasPer = TotTax/PumpPrice * 10;
            OilRange = OilCo/PumpPrice * 10;
            
   // Calculate BasePrice 
   // The equation given to us did not really work for me so I made my own
            
   double UnTax; // this number I will use to untax the PumpPrice
           UnTax = 1 + SalTax;
   BasePrice = PumpPrice/UnTax - OilCo - FedTax - StaTax;
   
   cout << "1) The base price for a gallon of gas is $" << BasePrice << endl;
   cout << "2) The total tax on a gallon of gas is $" << TotTax << endl;
   cout << "3) Percentage price due to gas tax is " << GasPer << endl;
   cout << "4) Oil Company profit percentage is " << OilRange << endl;
   
   
   
   
   
            return 0;
    
    
    }
    