/* 
 * File:   main.cpp
 * Author: Roy Chamorro
 * Created on February 28, 2018, 4:00 PM
 * Purpose:  Get the average Value
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv)
    {
      double var1, var2, var3, var4, var5, sum, average;
      var1 = 28;
      var2 = 32;
      var3 = 37;
      var4 = 24;
      var5 = 33;
      sum = var1 + var2 + var3 + var4 + var5;
      average = sum/5;
      
      cout << "The average of the five numbers is " << average << endl;
      
      return 0;
             
    }
    