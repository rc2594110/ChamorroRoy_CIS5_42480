/* 
 * File:   main.cpp
 * Author: Roy Chamorro
 * Created on February 18, 2018, 2:20 PM
 * Purpose:  CPP Template
 *           To be copied for each project
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv)
    {
    cout << "   *    \n";
    cout <<   "  ***   \n";
    cout <<   " *****  \n";
    cout <<   "******* \n";
    cout <<   " *****  \n";
    cout <<   "  ***   \n";
    cout <<   "   *   ";  
            
            return 0;
            
    }
    