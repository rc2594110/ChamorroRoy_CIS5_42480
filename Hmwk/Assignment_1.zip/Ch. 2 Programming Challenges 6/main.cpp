/* 
 * File:   main.cpp
 * Author: Roy Chamorro
 * Created on February 28, 2018, 4:09 PM
 * Purpose:  Annual Pay
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv)
    {
    double payAmount, payPeriods, annualPay;
    payAmount = 2200.0;
    payPeriods = 26;
    annualPay = payAmount * payPeriods;
            
    cout << "The total annual pay is $" << annualPay << endl;
    
    return 0;
    }
    