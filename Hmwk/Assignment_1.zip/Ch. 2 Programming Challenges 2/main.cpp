/* 
 * File:   main.cpp
 * Author: Roy Chamorro
 * Created on February 28, 2018, 3:48 PM
 * Purpose:  Sales Prediction
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv)
    {
    double WholeCo, EastDiv;
    
    WholeCo = 8.6;
    EastDiv = .58 * 8.6; 
            
            cout << "This year the East Coast Division of the company"
            " generated $" << EastDiv << " billion";
    
    return 0;
    
    
    
    
    
    
    }
    