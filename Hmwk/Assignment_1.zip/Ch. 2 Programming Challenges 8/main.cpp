/* 
 * File:   main.cpp
 * Author: Roy Chamorro
 * Created on March 1, 2018, 7:46 AM
 * Purpose:  Total Purchase
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv)
    {
     double item1, item2, item3, item4, item5, subTotal, salesTax, totalPurch;
     item1 = 15.95;
     item2 = 24.95;
     item3 = 6.95;
     item4 = 12.95;
     item5 = 3.95;
     subTotal = item1 + item2 + item3 + item4 + item5;
     salesTax = subTotal * .07;
     totalPurch = subTotal + salesTax;
     
     cout << "The prices of five items are as follows: $" << item1 << ", $" << item2; 
           cout << ", $" << item3 << ", $" << item4 << " & $" << item5 << ". \n"; 
  
     cout << "The subtotal of the sale of these five items is $" << subTotal << endl;
     
     cout << "The total amount of sales tax is $" << salesTax << endl;
     cout << "The total purchase price is $" << totalPurch << endl;
     
     return 0;   
    }
    