/* 
 * File:   main.cpp
 * Author: Roy Chamorro
 * Created on March 1, 2018, 7:44 AM
 * Purpose:  MPG
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv)
    {
    double tankGal, milesTravel, mpg;
    tankGal = 15;
    milesTravel = 375;
    mpg = milesTravel/tankGal;
    
    
    cout << "The car's mpg is " << mpg << " miles/gallon."; 
    
    return 0;
     
     
    }
    