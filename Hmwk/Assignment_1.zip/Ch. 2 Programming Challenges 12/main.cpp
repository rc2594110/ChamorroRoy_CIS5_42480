/* 
 * File:   main.cpp
 * Author: Roy Chamorro
 * Created on March 1, 2018, 
 * 8:08 AM
 * Purpose:  Land Acres
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv)
    {
    double acre, land, totalAcres;
     
    acre = 43560.0;
    land = 391876.0;
    totalAcres = land/acre; 
    
    cout << totalAcres << " acres";
    
    return 0;
    
    }
    