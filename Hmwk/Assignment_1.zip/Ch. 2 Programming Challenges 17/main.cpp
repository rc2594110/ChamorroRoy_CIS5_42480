/* 
 * File:   main.cpp
 * Author: Roy Chamorro
 * Created on March 1, 2018, 9:18 AM
 * Purpose:  Stock Commission 
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv)
    {
    double stockPrice, numberStock, amountStock, commish, total;
    
    stockPrice = 35.0;
    numberStock = 750;
    amountStock = stockPrice * numberStock;
    commish = amountStock * .02;
    total = amountStock + commish;
    
    cout << "The stocks alone total to $" << amountStock << " plus a 2 percent commission of $";
    cout << commish << " comes to a total of $" << total << endl;
    
    return 0;
     
     
    }
    