/* 
 * File:   main.cpp
 * Author: Roy Chamorro
 * Created on February 27, 2018,7:39 PM
 * Purpose:  Homework 1
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv)
    {
    double fifty, onehundred, total;
    
    fifty = 50;
    onehundred = 100;
    total = fifty + onehundred;
    
    cout << total << endl;
    
    return 0;
    
    }
    