/* 
 * File:   main.cpp
 * Author: Roy Chamorro
 * Created on March 1, 2018, 9:12 AM
 * Purpose:  To show how to use a single cout statement but multiple lines
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv)
    {
    cout << "Roy Chamorro \n25116 Wendy Way Moreno Valley, CA 92551 \n626-539-6429 \nPhilosophy Major"; 
    
    return 0;
     
     
    }
    