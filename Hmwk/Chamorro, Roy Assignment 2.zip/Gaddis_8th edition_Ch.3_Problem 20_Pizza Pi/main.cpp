/* 
 * File:   main.cpp
 * Author: Roy Chamorro
 * Created on March 11, 2018, 12:04 PM
 * Purpose:  Pizza Pi 
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
#include <cmath>
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv)
    {
    double diameter, radius, area, slice, pi = 3.14159;
    cout << "This program's purpose is to calculate the number of slices a pizza of any size";
    cout << "can be divided into.\n";
    cout << "Enter the desired diameter in inches for the pizza: ";
    cin >> diameter;
    radius = diameter / 2;
    area = pi * pow(radius, 2.0);
    slice = area / 14.25;
    
    cout << "With the desired pizza diameter of " << diameter << " inches, the ";
    cout << "number of slices will be " << slice << " slices.";
    
    
    return 0; 
     
    }
    