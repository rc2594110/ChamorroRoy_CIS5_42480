/* 
 * File:   main.cpp
 * Author: Roy Chamorro
 * Created on March 11, 2018, 9:46 AM
 * Purpose:  How many calories?
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv)
    {
    double cookie, calorie;
    
    cout << "How many cookies did you eat? ";
    cin >> cookie;
    calorie = cookie * 10;
    cout << "You consumed " << calorie << " calories.";
     
    return 0;
    }
    