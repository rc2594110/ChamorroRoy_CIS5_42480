/* 
 * File:   main.cpp
 * Author: Roy Chamorro
 * Created on March 11, 2018, 9:53 AM
 * Purpose:  Celsius to Fahrenheit
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv)
    {
    double C, F;
    cout << "This program serves to convert Celsius degrees to Fahrenheit \n";
    cout << "Enter the number of degrees Celsius: ";
    cin >> C;
    F = ((1.8) * C) + 32;
    cout << C << " degrees Celsius is equal to " << F << " degrees Fahrenheit.";
     
    return 0; 
    }
    