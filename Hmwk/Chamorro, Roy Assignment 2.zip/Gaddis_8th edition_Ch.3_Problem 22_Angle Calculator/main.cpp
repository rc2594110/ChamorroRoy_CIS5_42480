/* 
 * File:   main.cpp
 * Author: Roy Chamorro
 * Created on March 11, 2018, 4:20 PM
 * Purpose:  Total Purchase
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
#include <cmath>
#include <iomanip>
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv)
    {
    double a, s, c, t;
    cout << "Enter the value of angle in radians to find its sine, cosine and tangent: \n";
    cin >> a;
    s = sin(a);
    c = cos(a);
    t = tan(a);
    cout << setprecision(4) << fixed << endl;
    cout << "Sine: " << s << "\n";
    cout << "Cosine: " << c << "\n";
    cout << "Tangent: " << t;
    
    return 0;
     
    }
    