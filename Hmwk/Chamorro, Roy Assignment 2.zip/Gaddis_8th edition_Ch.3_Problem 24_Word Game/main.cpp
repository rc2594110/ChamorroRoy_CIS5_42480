/* 
 * File:   main.cpp
 * Author: Roy Chamorro
 * Created on February 28, 2018, 4:16 PM
 * Purpose:  Total Purchase
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
#include <string>
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv)
    {
    string name, city, college, profession, animal, petName;
    int age;
    cout << "What is your name? ";
    cin >> name;
    cin.ignore();
    cout << "How old are you? ";
    cin >> age;
    cin.ignore();
    cout << "Name any city: ";
    cin >> city;
    cin.ignore();
    cout << "Name a college: ";
    getline(cin, college);
    cin.ignore();          //I could not figure out how to delete the extra space here
    cout << "Name a profession: ";
    cin >> profession;
    cin.ignore();
    cout << "Name ANY animal: ";
    cin >> animal;
    cin.ignore();
    cout << "What is a good pet name? ";
    cin >> petName;
    cin.ignore();
    cout << "There once was a person named " << name; 
    cout << " who lived in " << city << ". "; 
    cout << "At the age of " << age << " " << name << " went to college at " << college << ". "; 
    cout << name << " graduated and went to work as a " << profession << ". "; 
    cout << "Then, " << name << " adopted a(n) " << animal << " named " << petName << ". "; 
    cout << "They both lived happily ever after!";
     
    return 0; 
   
    }
    