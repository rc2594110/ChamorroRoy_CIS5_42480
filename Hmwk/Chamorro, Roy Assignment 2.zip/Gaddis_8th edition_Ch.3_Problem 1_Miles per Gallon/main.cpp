/* 
 * File:   main.cpp
 * Author: Roy Chamorro
 * Created on March 9, 2018, 11:37 AM
 * Purpose:  Miles per Gallon
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv)
    {
    double fullTank, fullDistance, MPG;
    
    cout << "Enter the number of gallons your car's tank holds and the number of miles it can go with a full tank \n";
    cout << "Full Tank in Gallons: ";
    cin >> fullTank;
    cout << "Full distance on a full tank in miles: ";
    cin >> fullDistance; 
    MPG = fullDistance / fullTank;
    cout << "Your car's MPG is " << MPG << " miles per gallon";
    
  
    
    
    return 0;
     
     
    }
    