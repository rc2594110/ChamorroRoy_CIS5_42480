/* 
 * File:   main.cpp
 * Author: Roy Chamorro
 * Created on March 10, 2018, 10:12 AM
 * Purpose:  Average Test Score
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
#include <iomanip>
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv)
    {
    double t1, t2, t3, t4, t5, sum, average;
    cout << "Enter five test scores: \n";
    cout << setprecision(1) << fixed;
    cin >> t1;
    cin >> t2;
    cin >> t3;
    cin >> t4;
    cin >> t5;
    sum = t1 + t2 + t3 + t4 + t5;
    average = sum / 5;
    
    cout << "The average of the five test scores is " << average;
    
    return 0;
     
     
    }
    