/* 
 * File:   main.cpp
 * Author: Roy Chamorro
 * Created on March 11, 2018, 10:04 AM
 * Purpose:  Math Tutor
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
#include <cstdlib> // For rand and srand
#include <iomanip>
#include <ctime>
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv)
    {
    int a, b, c;
    const int MIN_VALUE = 1;
    const int MAX_VALUE = 999;
    unsigned seed = time(0);
    srand(seed);
    a = (rand() % (MAX_VALUE - MIN_VALUE + 1)) + MIN_VALUE;
    b = (rand() % (MAX_VALUE - MIN_VALUE + 1)) + MIN_VALUE;
    cout << "This program is designed to help you practice addition.\n";
    cout << setw(4) << a << "\n";
    cout << setw(1) << "+" << b;
    cin.ignore();
    c = a + b;
    cout << setw(4) << c;
    
    return 0;
     
    }
    