/* 
 * File:   main.cpp
 * Author: Roy Chamorro
 * Created on March 10, 2018, 10:22 AM
 * Purpose:  How Many Widgets?
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv)
    {
    double palletAlone, palletFull, widget; 
    
    cout << "This program was made to calculate the number of Yukon widgets stacked on a particular pallet. \n";
    cout << "How much does the pallet weigh in lbs on its own? ";
    cin >> palletAlone;
    cout << "How much does the pallet weigh in lbs with the widgets stacked on? ";
    cin >> palletFull;
    widget = (palletFull - palletAlone) / 12.5;
    cout << "There are " << widget << " widgets stacked on the pallet.";
    
    return 0;
     
    }
    