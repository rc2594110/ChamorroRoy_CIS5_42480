/* 
 * File:   main.cpp
 * Author: Roy Chamorro
 * Created on March 9, 2018, 12:26 PM
 * Purpose:  Stadium Seating
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
#include <iomanip>
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv)
    {
    double classA, classB, classC, total;
    
    cout << "How many Class A tickets were sold? Class B? Class C? \n";
    cout << "Total number of Class A tickets sold: ";
    cout << setprecision(2) << fixed;
    cin >> classA;
    classA *= 15.00;
    cout << "Total number of Class B tickets sold: ";
    cin >> classB;
    classB *= 12.00;
    cout << "Total number of Class C tickets sold: ";
    cin >> classC;
    classC *= 9.00;
    total = classA + classB + classC;
    cout << "The total income generated at the stadium was $" << total << endl;
    
     
    
    
    return 0;
            
     
     
    }
    